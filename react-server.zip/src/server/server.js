//설치한 라이브러리 

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mysql = require('mysql');



// Express 애플리케이션 생성
const app = express();

// 포트 설정
const PORT = process.env.PORT || 5000;

app.use(bodyParser.json());
app.use(cors());

app.listen(PORT, () => {
    console.log(`Server On : http://localhost:${PORT}`);
});

// DB 접속
const db = mysql.createConnection({
    host: 'localhost',
    user: 'user_react',
    password: '1111',
    port: '3306',
    database: 'db_react'
});


db.connect((err) => {

    if(!err) {
        console.log('DB 접속 성공!!');
    } else {
        console.log('DB 접속 실패!!');
    }

});








