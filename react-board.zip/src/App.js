import './App.css';
import BoardMain from './component/BoardMain';

function App() {
  return (
    <div className="App">
      <BoardMain />
    </div>
  );
}

export default App;
