import React, { useEffect , useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { Button, Row, Col, Card } from 'react-bootstrap';

const BoardView = () => {

    const { id } = useParams();

    const [board , setBoard] = useState({});

    const getBoard = async() => {
        const board = await axios.get(`/view/${id}`);
        setBoard(board.data[0]);
    }

    useEffect(()=>{
        getBoard();
    }, []);

    const onDelete = async() => {
        if(window.confirm(`${id}번 게시글을 삭제하시겠습니까?`)){
            // 해당 게시글을 삭제하는 명력어 작성!
            await axios.post(`/delete/${id}`);
            window.location.href = "/";
        }
    }
    

    return (
        <div className='board-view'>
            <Row className='my-5'>
                <Col className='px-5'>
                    <h1 className='my-5 text-center'>{board.id}번 게시글 정보</h1>
                    
                    <div className='text-end my-2'>
                        <Link to = {{
                            pathname : `/modify/${id}`
                        }} >
                        <Button className='btn-sm mx-2'>수정</Button></Link>
                        <Button className='btn-sm' variant='danger' onClick={onDelete}>삭제</Button>
                    </div>

                    <Card>
                        <Card.Body>
                            <h5>[{board.id}] {board.title}</h5>
                            <hr/>
                            <div className='cArea'>{board.contents}</div>
                        </Card.Body>

                        <Card.Footer>
                            Created on {board.reg_date} by {board.writer}
                        </Card.Footer>
                    </Card>
                </Col>
            </Row>
        </div>
    );
};

export default BoardView;