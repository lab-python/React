import { Table, Button } from 'react-bootstrap'
import { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom'

const BoardList = () => {

    const [boardList, setBoardList] = useState({});

    // hook의 일종
    // 마운트와 업데이트 사이
    // 컴포넌트가 랜더링 될 때 , 업데이트 될 때 실행

    const getBoardData = async () => {
        const board = await axios('/list');
        console.log(board);
        setBoardList(board.data);
    }

    // async () : 
    // 비동기 함수 : 특정 코드가 끝날때 까지 코드의 실행을 멈추지 않고 다음 코드를 먼저 실행하는 것을 의미

    // async와 await는 자바스크립트의 비동기 처리 패턴 중 가장 최근에 나온 문법이다. 
    // 기존의 비동기 처리 방식인 콜백 함수와 프로미스의 단점을 보완하고 개발자가 
    // 읽기 좋은 코드를 작성할 수 있게 도와준다. 특히, 복잡했던 Promise를 조금 더 편하게 사용할 수 있다. 

    // xx async 키워드는 function 앞에 사용한다. 
    // xx function 앞에 async를 붙이면 해당 함수는 항상 프라미스를 반환한다. 
    // xx 프라미스가 아닌 값을 반환하더라도 이행 상태의 프라미스(resolved promise)로 
    // xx 값을 감싸 이행된 프라미스가 반환되도록 한다.

    // ES6에서는 비동기 처리를 위한 또 다른 패턴으로 프로미스(Promise)를 도입했다. 
    // 프로미스는 전통적인 콜백 패턴이 가진 단점을 보완하며 비동기 처리 시점을 
    // 명확하게 표현할 수 있다는 장점이 있다.

    // await는 async 함수 안에서만 동작한다. await는 ‘기다리다'라는 뜻을 가진 영단어 인데, 
    // 프라미스가 처리될 때 까지 기다리는 역할을 한다. 그리고 결과는 그 이후 반환된다.

    useEffect(() => {
        getBoardData()
    }, []); // 



    if (boardList.length > 0) {
        return (
            <div className='board-list'>
                <h1>게시글 목록</h1>

                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>번호</th>
                            <th>제목</th>
                            <th>작성자</th>
                            <th>작성일</th>
                        </tr>
                    </thead>
                    <tbody>
                        {boardList.map(b => (
                            <tr key={b.id}>
                                <td>{b.id}</td>
                                <td>
                                    <Link to={{
                                        pathname: `/view/${b.id}`
                                    }}>{b.title}</Link>
                                </td>
                                <td>{b.writer}</td>
                                <td>{b.reg_date}</td>
                            </tr>)
                        )}
                    </tbody>

                </Table>
                <Link to={`/write`} >
                    <Button className='mx-2 btnWrite'>작성하기</Button>
                </Link>
            </div>


        );
    }
}

export default BoardList;