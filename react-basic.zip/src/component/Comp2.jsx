
import React, { useState } from 'react';


// state : 일반 자바 객체로 component에서 변할 수 있는 값
// useState(): react hooks
// state를 바꾸기 위해서 set함수를 실행해야 useState가 감지해서
// 자식 컴포넌트까지 재랜더링이 발생한다.
// Hook은 함수형 컴포넌트에서 리액트의 state와 
// 생명주기 기능을 연동(hook) 할 수 있게 해주는 함수


const Comp2 = () => {

    // const [ 변수명, 함수명 ] = useState(초기값);
    const [param1, setParam1] = useState('초기값');
    
    const func1 = () => {
        setParam1('안녕하세요');
    } 

    const func2 = () => {
        setParam1('');
    }

    // 카운트 
    const [count, setCount] = useState(100);

    const onIncrease = () => {
        setCount(count + 1);
    }

    const onDecrease = () => {
        setCount(count - 1);
    }

    // 텍스트 필드 입력 값
    const [param2, setParam2] = useState('');

    const textInput = (e) => {
        console.log(`name : ${e.target.name}`);        
        console.log(`value : ${e.target.value}`);
        setParam2(e.target.value);        
    }

    // 스타일 적용
    const [color, setColor] = useState('red');


    return (
        <div className='comp2 comp'>
            {/* <h2>이곳은 Comp2.jsx 입니다.</h2> */}

            <p>{param1}</p>
            <button onClick={func1}>버튼</button>&nbsp;
            <button onClick={func2}>초기화</button>
            <br/>

            <h1>count : {count}</h1>
            <div>
                <button onClick={onDecrease}>감소</button>&nbsp;
                <button onClick={onIncrease}>증가</button>
            </div>
            <br/>

            <input type="text" onChange={textInput} name="param2" />
            <p>입력값: {param2}</p>
            <br/>

            <h1 style={{background:color, color:"white"}}>안녕하세요</h1>
            <div>
                <button onClick={()=>setColor("red")}>빨강</button>&nbsp;
                <button onClick={()=>setColor("blue")}>파랑</button>&nbsp;
                <button onClick={()=>setColor("green")}>초록</button>&nbsp;
            </div>

        </div>
    );

};

export default Comp2;