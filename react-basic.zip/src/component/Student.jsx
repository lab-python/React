
import React from 'react';

// pros : 상위 컴포넌트에서 하위 컴포넌트로 파라미터를 전달 할 수 있다.

const Student = (props) => {

    const {name, age, addr } = props.stu;

    return (
        <div className='student'>
            <p>이름 : {name}, 나이 : {age}, 주소 : {addr}</p>                       
        </div>
    )
}

export default Student;