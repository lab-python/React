
import React from 'react';
import { Link } from 'react-router-dom';

/*
    파라미터 전송
    1. Path Variable :  /param/20
    2. query string :   /param?q=aa&page=10
*/ 


const Comp3 = () => {
    return (
        <div className='comp3 comp'>
            <div>
                {/* <h2>이곳은 Comp3.jsx 입니다.</h2> */}
                <Link to={{
                    pathname: '/param/20'
                }}>
                    param 전송 (Path Variable) 
                </Link>
            </div>

            <div>
                {/* <Link to="/param?q=aa&page=10">Param전송</Link> */}
                <Link to={{
                    pathname: "/param",
                    search: "?q=bb&page=20"
                }}>param전송(Query String)
                </Link>
                <br/>
            </div>

        </div>
    );
};

export default Comp3;