
import React from 'react';

// 함수형 컴포넌트
const Start = () => {

    const name = 'kso';
    
    const style = {
        color : "white",
        backgroundColor : "black",
        fontSize : "48px",
        fontWeight : "bold",
        padding : "16px"
    }

    
    // JSX : 자바스크립트 확장 문법  
    // JavaScript and XML
    // JavaScript and HTML    
    // 코드 간결, 가독성 좋음
    // 자바스크립트 코드 사용 : { 자바 스크립트 코드 } 

    
    // React Eelment를 반환한다.
    return (
        <div className='start'>
            <h2>이 곳은 Start.jsx 영역입니다.</h2>
            <h2>Start.jsx의 내용이 출력됩니다.</h2>

            {/* React.createElement('h2', null, `${name}님 반갑습니다.`); */}
            <h2 style={style}>{name}님 반갑습니다.</h2>

        </div>
    );
};

export default Start;