
import React from 'react';
import { student, students } from '../data/data'
import Student from './Student';


const Comp1 = () => {

    return (
        <div className='comp1 comp'> 
           {/* <h2>이곳은 Comp1.jsx 입니다.</h2> */}

           <p>{student.name}, {student.age}, {student.addr} </p>
           <br/><hr/><br/>

            {/* 
            {
                students.map(s => (
                    <p>{s.name}, {s.age}, {s.addr} </p>
                ))
            } 
            */}


            {/* 상위 컴포넌트(Comp1)에서 하위 컴포넌트(Student)로 파라미터를 전달 할 수 있다. */}

            {   
                students.map(s => (
                    <Student stu={s} />
                ))

            }

        </div>
    );
};

export default Comp1;