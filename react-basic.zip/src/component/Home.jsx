
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './Header';
import Start from './Start';
import Comp1 from './Comp1';
import Comp2 from './Comp2';
import Comp3 from './Comp3';
import Param1 from './Param1';
import Param2 from './Param2';



// 함수형 컴포넌트
const Home = () => {
    return (
        <div className='home'>
            {/* <h2>이곳은 Home.jsx 입니다.</h2> */}

            {/* 화면 전환 : BrowerRouter 컴포넌트 사용 */}
            <BrowserRouter>
                <Header />

                <Routes>
                    <Route path='/' element={<Start />}></Route>
                    <Route path='/comp1' element={<Comp1 />}></Route>
                    <Route path='/comp2' element={<Comp2 />}></Route>
                    <Route path='/comp3' element={<Comp3 />}></Route>
                    {/* param 전송 : path variable */}
                    <Route path='/param/:id' element={<Param1 />}></Route>
                    {/* param 전송 : query string */}
                    <Route path='/param' element={<Param2 />}></Route>                   
                </Routes>
            
            </BrowserRouter>

        </div>
    );
};

export default Home;