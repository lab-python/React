
import React from 'react';
import { useSearchParams } from 'react-router-dom';

const Param2 = () => {

   const [params] = useSearchParams();     
   
   console.log(params.size);

   // [['q', 'bb'], ['page', '20']]
   const search = [...params];
   console.log(search);



    return (
        <div>
            {/* <h2>이곳은 Param2.jsx 입니다.</h2> */}

            {
                search.map((s) => (
                    <p>{s[0]} : {s[1]}</p>
                ))
            }

        </div>
    );
};

export default Param2;