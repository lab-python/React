
import React from 'react';
import { useParams } from 'react-router-dom';

const Param1 = () => {

    // 파라미터 : path variable     
    const { id } = useParams();


    return (
        <div>
            <h2>이곳은 Param1.jsx 입니다.</h2>
            <p>요청 id : {id}</p>
        </div>
    );
};

export default Param1;