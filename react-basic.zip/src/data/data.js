export const student = {
    name : "일길동",
    age : 10,
    addr : "서울"
}


export const students = [
    {
        name : "일길동",
        age : 10,
        addr : "서울"
    }, 
    {
        name : "이길동",
        age : 20,
        addr : "경기"
    },
    {
        name : "삼길동",
        age : 30,
        addr : "부산"
    },
    {
        name : "사길동",
        age : 40,
        addr : "제주"
    }
]