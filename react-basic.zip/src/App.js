import './App.css';
import Header from './component/Header';
import Footer from './component/Footer';
import Start from './component/Start';
import Home from './component/Home';



function App() {
  return (
    <div className="App">      

       {/* <h2>이곳은 App.js 영역입니다.</h2>  */}       
       {/* <Start /> */}
       <Home />

      <Footer />
    </div>
  );
}

export default App;
