import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import BoardList from './BoardList';
import BoardWrite from './BoardWrite';
import BoardView from './BoardView';
import BoardModify from './BoardModify';


const BoardMain = () => {
    return (
        <div className='board-main'>
            {/* BrowserRouter : 화면 전환  */}
            <BrowserRouter>
                <Routes>
                    <Route path='/' element={<BoardList />} />
                    <Route path='/write' element={<BoardWrite />} />
                    {/* 파라미터 전송 : path variable */}
                    <Route path='/view/:id' element={<BoardView />} />
                     {/* 파라미터 전송 : path variable */}
                    <Route path='/modify/:id' element={<BoardModify />} />                    
                </Routes>
            </BrowserRouter>            
        </div>
    )};

export default BoardMain;